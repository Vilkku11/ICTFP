:orphan:

=============
pip-uninstall
=============

Description
***********

.. pip-command-description:: uninstall

Usage
*****

.. pip-command-usage:: uninstall

Options
*******

.. pip-command-options:: uninstall

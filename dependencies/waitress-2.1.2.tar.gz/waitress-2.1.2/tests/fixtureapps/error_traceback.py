def app(environ, start_response):  # pragma: no cover
    raise ValueError("Invalid application: " + chr(8364))
